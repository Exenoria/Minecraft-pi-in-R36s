#ifndef GLES1_SHIM_H__
#define GLES1_SHIM_H__

/*
 * gles1_shim: OpenGL ES 1.1 (fixed-function) emulado sobre OpenGL ES 2.0.
 *
 * El juego (Minecraft Pocket Edition 2013) solo usa la tuberia fija de GLES 1.1
 * (glMatrixMode, glTranslatef, glFogf, glAlphaFunc, client arrays, VBOs...).
 * La GPU de la R36S (Mali-G31) solo ofrece GLES 2/3, asi que este modulo
 * implementa los puntos de entrada glXxx() de GLES 1.1 con un par de shaders
 * y pila de matrices propia. No hace falta gl4es ni libGLESv1_CM.
 *
 * Uso:
 *   1. Crear un contexto GLES 2.0 (SDL_GL_CreateContext, EGL, ...).
 *   2. gles1shim_init(SDL_GL_GetProcAddress)   <- con el contexto activo
 *   3. Llamar a las funciones glXxx() de GLES 1.1 como siempre.
 */

#ifdef __cplusplus
extern "C" {
#endif

typedef void* (*Gles1ShimLoader)(const char* name);

/* Devuelve 1 si todo fue bien. Debe llamarse con el contexto GLES2 activo. */
int  gles1shim_init(Gles1ShimLoader loader);
void gles1shim_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif /* GLES1_SHIM_H__ */
