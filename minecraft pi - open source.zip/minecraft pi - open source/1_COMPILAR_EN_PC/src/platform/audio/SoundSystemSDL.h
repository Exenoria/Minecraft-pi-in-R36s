#ifndef SoundSystemSDL_H__
#define SoundSystemSDL_H__

// Sistema de sonido SDL2 para el port R36S: mezcla por software los efectos PCM
// que ya vienen compilados dentro del juego (client/sound/data/*.pcm).
// Volumen por distancia lo calcula SoundEngine; aqui se hace el panorama (izq/der),
// el cambio de tono (pitch) y la mezcla de varias voces a la vez.

#include "SoundSystem.h"
#include <vector>

class SoundSystemSDL : public SoundSystem
{
public:
	SoundSystemSDL();
	virtual ~SoundSystemSDL();

	virtual bool isAvailable() { return _device != 0; }
	virtual void setListenerAngle(float deg) { _listenerYaw = deg; }
	virtual void playAt(const SoundDesc& desc, float x, float y, float z, float volume, float pitch);

	// llamado desde el hilo de audio de SDL
	void mix(short* out, int frames);

private:
	struct Voice {
		const unsigned char* data;  // PCM 16-bit little endian
		int   numFrames;
		int   channels;             // 1 o 2
		double pos;                 // posicion de lectura (en frames de origen)
		double step;                // avance por frame de salida (tono + remuestreo)
		float gainL, gainR;
		bool  active;
		unsigned long serial;
	};

	static const int MAX_VOICES = 16;

	unsigned int _device;           // SDL_AudioDeviceID (0 = sin audio)
	int          _outRate;
	Voice        _voices[MAX_VOICES];
	unsigned long _serial;
	float        _listenerYaw;
	std::vector<float> _acc;
};

#endif /*SoundSystemSDL_H__ */
