#include "SoundSystemSDL.h"
#include "../../client/sound/Sound.h"
#include "../log.h"

#include <SDL2/SDL.h>
#include <cmath>
#include <cstring>

static void sdlAudioCallback(void* userdata, Uint8* stream, int len)
{
	SoundSystemSDL* self = (SoundSystemSDL*)userdata;
	self->mix((short*)stream, len / 4); // 16-bit estereo = 4 bytes por frame
}

SoundSystemSDL::SoundSystemSDL()
:	_device(0),
	_outRate(44100),
	_serial(0),
	_listenerYaw(0)
{
	memset(_voices, 0, sizeof(_voices));

	if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0) {
		LOGI("Audio: SDL_INIT_AUDIO fallo (%s). Sin sonido.\n", SDL_GetError());
		return;
	}

	SDL_AudioSpec want;
	SDL_AudioSpec have;
	memset(&want, 0, sizeof(want));
	memset(&have, 0, sizeof(have));
	want.freq = 44100;
	want.format = AUDIO_S16SYS;
	want.channels = 2;
	want.samples = 1024;
	want.callback = sdlAudioCallback;
	want.userdata = this;

	// allowed_changes = 0: SDL convierte por su cuenta a lo que pidamos
	_device = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
	if (_device == 0) {
		LOGI("Audio: no se pudo abrir el dispositivo (%s). Sin sonido.\n", SDL_GetError());
		return;
	}
	_outRate = have.freq > 0 ? have.freq : 44100;
	_acc.assign((size_t)(have.samples > 0 ? have.samples : 2048) * 2 * 2, 0.0f);
	LOGI("Audio listo: %d Hz, %d canales, buffer %d\n", have.freq, (int)have.channels, (int)have.samples);
	SDL_PauseAudioDevice(_device, 0);
}

SoundSystemSDL::~SoundSystemSDL()
{
	if (_device) {
		SDL_CloseAudioDevice(_device);
		_device = 0;
	}
}

void SoundSystemSDL::playAt(const SoundDesc& desc, float x, float y, float z, float volume, float pitch)
{
	if (!_device || !desc.isValid()) return;
	if (desc.byteWidth != 2 || desc.numFrames <= 1 || desc.frameRate <= 0) return;
	if (desc.channels != 1 && desc.channels != 2) return;
	if (volume <= 0.0f) return;
	if (volume > 1.0f) volume = 1.0f;
	if (pitch < 0.25f) pitch = 0.25f;
	if (pitch > 4.0f) pitch = 4.0f;

	// panorama: x,y,z llegan relativos al jugador; "derecha" del jugador segun su yaw
	float pan = 0.0f;
	const float dist = sqrtf(x * x + y * y + z * z);
	if (dist > 0.001f) {
		const float rad = _listenerYaw * 3.14159265f / 180.0f;
		const float rx = -cosf(rad), rz = -sinf(rad);
		pan = (x * rx + z * rz) / dist;
		if (pan > 1.0f) pan = 1.0f;
		if (pan < -1.0f) pan = -1.0f;
	}
	const float a = (pan + 1.0f) * 0.78539816f;   // 0..pi/2
	const float gl = 1.41421356f * cosf(a) * volume * 0.8f;
	const float gr = 1.41421356f * sinf(a) * volume * 0.8f;

	SDL_LockAudioDevice(_device);
	int slot = -1;
	for (int i = 0; i < MAX_VOICES; ++i) {
		if (!_voices[i].active) { slot = i; break; }
	}
	if (slot < 0) { // todas ocupadas: se roba la mas antigua
		unsigned long oldest = _voices[0].serial;
		slot = 0;
		for (int i = 1; i < MAX_VOICES; ++i) {
			if (_voices[i].serial < oldest) { oldest = _voices[i].serial; slot = i; }
		}
	}
	Voice& v = _voices[slot];
	v.data = (const unsigned char*)desc.frames;
	v.numFrames = desc.numFrames;
	v.channels = desc.channels;
	v.pos = 0.0;
	v.step = ((double)desc.frameRate / (double)_outRate) * (double)pitch;
	v.gainL = gl;
	v.gainR = gr;
	v.serial = ++_serial;
	v.active = true;
	SDL_UnlockAudioDevice(_device);
}

static inline float readSample(const unsigned char* p, int index)
{
	const int lo = p[2 * index];
	const int hi = p[2 * index + 1];
	return (float)(short)(lo | (hi << 8));
}

void SoundSystemSDL::mix(short* out, int frames)
{
	if ((int)_acc.size() < frames * 2) _acc.assign((size_t)frames * 2, 0.0f);
	float* acc = &_acc[0];
	for (int i = 0; i < frames * 2; ++i) acc[i] = 0.0f;

	for (int vi = 0; vi < MAX_VOICES; ++vi) {
		Voice& v = _voices[vi];
		if (!v.active) continue;
		const int last = v.numFrames - 1;
		for (int i = 0; i < frames; ++i) {
			const int idx = (int)v.pos;
			if (idx >= last) { v.active = false; break; }
			const float frac = (float)(v.pos - (double)idx);
			float sl, sr;
			if (v.channels == 1) {
				const float s0 = readSample(v.data, idx);
				const float s1 = readSample(v.data, idx + 1);
				sl = sr = s0 + (s1 - s0) * frac;
			} else {
				const float l0 = readSample(v.data, 2 * idx),     r0 = readSample(v.data, 2 * idx + 1);
				const float l1 = readSample(v.data, 2 * idx + 2), r1 = readSample(v.data, 2 * idx + 3);
				sl = l0 + (l1 - l0) * frac;
				sr = r0 + (r1 - r0) * frac;
			}
			acc[2 * i]     += sl * v.gainL;
			acc[2 * i + 1] += sr * v.gainR;
			v.pos += v.step;
		}
	}

	for (int i = 0; i < frames * 2; ++i) {
		float s = acc[i];
		if (s > 32767.0f) s = 32767.0f;
		if (s < -32768.0f) s = -32768.0f;
		out[i] = (short)s;
	}
}
