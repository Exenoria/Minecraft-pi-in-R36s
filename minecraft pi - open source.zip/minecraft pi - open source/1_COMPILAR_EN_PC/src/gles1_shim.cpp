// gles1_shim.cpp - OpenGL ES 1.1 (fixed function) emulado sobre OpenGL ES 2.0.
// Ver gles1_shim.h. Solo implementa lo que usa Minecraft PE (y algo mas por seguridad).

#include "gles1_shim.h"

#include <GLES/gl.h>   // declaraciones GLES1: aqui DEFINIMOS esos puntos de entrada

#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>
#include <cstring>
#include <cmath>
#include <map>
#include <string>

#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_VERTEX_SHADER   0x8B31
#define GL_COMPILE_STATUS  0x8B81
#define GL_LINK_STATUS     0x8B82
#endif
#ifndef GL_EXP2
#define GL_EXP2 0x0801
#endif
#ifndef GL_TEXTURE_MATRIX
#define GL_TEXTURE_MATRIX 0x0BA8
#endif
#define SHIM_MATRIX_MODE 0x0BA0

// ---------------------------------------------------------------------------
// Funciones reales de GLES 2.0 (cargadas con el loader; nombres es2_*)
// ---------------------------------------------------------------------------
#define ES2_FUNCS(X) \
	X(void,           glActiveTexture,            (GLenum)) \
	X(void,           glAttachShader,             (GLuint, GLuint)) \
	X(void,           glBindAttribLocation,       (GLuint, GLuint, const char*)) \
	X(void,           glBindBuffer,               (GLenum, GLuint)) \
	X(void,           glBindTexture,              (GLenum, GLuint)) \
	X(void,           glBlendFunc,                (GLenum, GLenum)) \
	X(void,           glBufferData,               (GLenum, GLsizeiptr, const void*, GLenum)) \
	X(void,           glBufferSubData,            (GLenum, GLintptr, GLsizeiptr, const void*)) \
	X(void,           glClear,                    (GLbitfield)) \
	X(void,           glClearColor,               (GLfloat, GLfloat, GLfloat, GLfloat)) \
	X(void,           glClearDepthf,              (GLfloat)) \
	X(void,           glColorMask,                (GLboolean, GLboolean, GLboolean, GLboolean)) \
	X(void,           glCompileShader,            (GLuint)) \
	X(GLuint,         glCreateProgram,            (void)) \
	X(GLuint,         glCreateShader,             (GLenum)) \
	X(void,           glCullFace,                 (GLenum)) \
	X(void,           glDeleteBuffers,            (GLsizei, const GLuint*)) \
	X(void,           glDeleteShader,             (GLuint)) \
	X(void,           glDeleteTextures,           (GLsizei, const GLuint*)) \
	X(void,           glDepthFunc,                (GLenum)) \
	X(void,           glDepthMask,                (GLboolean)) \
	X(void,           glDepthRangef,              (GLfloat, GLfloat)) \
	X(void,           glDisable,                  (GLenum)) \
	X(void,           glDisableVertexAttribArray, (GLuint)) \
	X(void,           glDrawArrays,               (GLenum, GLint, GLsizei)) \
	X(void,           glDrawElements,             (GLenum, GLsizei, GLenum, const void*)) \
	X(void,           glEnable,                   (GLenum)) \
	X(void,           glEnableVertexAttribArray,  (GLuint)) \
	X(void,           glFinish,                   (void)) \
	X(void,           glFlush,                    (void)) \
	X(void,           glFrontFace,                (GLenum)) \
	X(void,           glGenBuffers,               (GLsizei, GLuint*)) \
	X(void,           glGenTextures,              (GLsizei, GLuint*)) \
	X(void,           glGenerateMipmap,           (GLenum)) \
	X(GLenum,         glGetError,                 (void)) \
	X(void,           glGetFloatv,                (GLenum, GLfloat*)) \
	X(void,           glGetIntegerv,              (GLenum, GLint*)) \
	X(void,           glGetProgramInfoLog,        (GLuint, GLsizei, GLsizei*, char*)) \
	X(void,           glGetProgramiv,             (GLuint, GLenum, GLint*)) \
	X(void,           glGetShaderInfoLog,         (GLuint, GLsizei, GLsizei*, char*)) \
	X(void,           glGetShaderiv,              (GLuint, GLenum, GLint*)) \
	X(const GLubyte*, glGetString,                (GLenum)) \
	X(GLint,          glGetUniformLocation,       (GLuint, const char*)) \
	X(GLboolean,      glIsEnabled,                (GLenum)) \
	X(void,           glLineWidth,                (GLfloat)) \
	X(void,           glLinkProgram,              (GLuint)) \
	X(void,           glPixelStorei,              (GLenum, GLint)) \
	X(void,           glPolygonOffset,            (GLfloat, GLfloat)) \
	X(void,           glReadPixels,               (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*)) \
	X(void,           glScissor,                  (GLint, GLint, GLsizei, GLsizei)) \
	X(void,           glShaderSource,             (GLuint, GLsizei, const char* const*, const GLint*)) \
	X(void,           glTexImage2D,               (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*)) \
	X(void,           glTexParameteri,            (GLenum, GLenum, GLint)) \
	X(void,           glTexSubImage2D,            (GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*)) \
	X(void,           glUniform1f,                (GLint, GLfloat)) \
	X(void,           glUniform1i,                (GLint, GLint)) \
	X(void,           glUniform4f,                (GLint, GLfloat, GLfloat, GLfloat, GLfloat)) \
	X(void,           glUniformMatrix4fv,         (GLint, GLsizei, GLboolean, const GLfloat*)) \
	X(void,           glUseProgram,               (GLuint)) \
	X(void,           glVertexAttrib4f,           (GLuint, GLfloat, GLfloat, GLfloat, GLfloat)) \
	X(void,           glVertexAttribPointer,      (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*)) \
	X(void,           glViewport,                 (GLint, GLint, GLsizei, GLsizei))

#define X(ret, name, args) static ret (*es2_##name) args = 0;
ES2_FUNCS(X)
#undef X

// ---------------------------------------------------------------------------
// Estado emulado
// ---------------------------------------------------------------------------
namespace {

struct ArrayState {
	bool enabled;
	GLint size;
	GLenum type;
	GLsizei stride;
	const void* ptr;
};

struct Prog {
	GLuint id;
	bool tried, ok;
	GLint uMVP, uTexMat, uEyeZ, uTex, uFogColor, uFogParam, uAlphaRef, uAlphaFunc;
};

struct State {
	bool inited;

	float mv[32][16];  int mvTop;
	float proj[8][16]; int projTop;
	float tex[4][16];  int texTop;
	GLenum matrixMode;

	bool tex2d, alphaTest, fog;
	GLenum alphaFunc;  float alphaRef;
	GLenum fogMode;    float fogDensity, fogStart, fogEnd, fogColor[4];
	float color[4];

	ArrayState vtx, tcoord, col, nrm;
	bool attribOn[3];

	// caps "normales" que seguimos para poder restaurarlas tras dibujar el overlay
	bool capBlend, capDepth, capCull, capScissor;
	GLenum blendSrc, blendDst;

	GLuint boundTex;
	std::map<GLuint, GLuint> vboMap;   // id del juego -> id real
	std::map<GLuint, int>    texFlags; // bit0: pide mipmaps

	Prog prog[16];
};

State S;

static void mat_identity(float* m) {
	memset(m, 0, 16 * sizeof(float));
	m[0] = m[5] = m[10] = m[15] = 1.0f;
}

// r = a * b (column-major, como OpenGL)
static void mat_mul(float* r, const float* a, const float* b) {
	float t[16];
	for (int c = 0; c < 4; ++c) {
		for (int row = 0; row < 4; ++row) {
			float s = 0.0f;
			for (int k = 0; k < 4; ++k) s += a[k * 4 + row] * b[c * 4 + k];
			t[c * 4 + row] = s;
		}
	}
	memcpy(r, t, sizeof(t));
}

static float* cur_mat() {
	switch (S.matrixMode) {
		case GL_PROJECTION: return S.proj[S.projTop];
		case GL_TEXTURE:    return S.tex[S.texTop];
		default:            return S.mv[S.mvTop];
	}
}

static void post_mul(const float* t) {
	float* m = cur_mat();
	mat_mul(m, m, t);
}

static void sync_attrib(int i, bool want) {
	if (S.attribOn[i] != want) {
		if (want) es2_glEnableVertexAttribArray((GLuint)i);
		else      es2_glDisableVertexAttribArray((GLuint)i);
		S.attribOn[i] = want;
	}
}

// ---------------------------------------------------------------------------
// Shaders
// ---------------------------------------------------------------------------
static const char* kVertexSrc =
	"attribute vec4 aPos;\n"
	"attribute vec2 aTex;\n"
	"attribute vec4 aCol;\n"
	"uniform mat4 uMVP;\n"
	"uniform mat4 uTexMat;\n"
	"uniform vec4 uEyeZ;\n"
	"varying vec2 vTex;\n"
	"varying vec4 vCol;\n"
	"varying float vFogD;\n"
	"void main() {\n"
	"  gl_Position = uMVP * aPos;\n"
	"  vTex = (uTexMat * vec4(aTex, 0.0, 1.0)).xy;\n"
	"  vCol = aCol;\n"
	"  vFogD = abs(dot(uEyeZ, aPos));\n"
	"}\n";

static const char* kFragmentSrc =
	"precision mediump float;\n"
	"#ifdef GL_FRAGMENT_PRECISION_HIGH\n"
	"#define HP highp\n"
	"#else\n"
	"#define HP mediump\n"
	"#endif\n"
	"varying vec2 vTex;\n"
	"varying vec4 vCol;\n"
	"varying HP float vFogD;\n"
	"uniform sampler2D uTex;\n"
	"uniform HP vec4 uFogParam;\n"   // x=start y=end z=density
	"uniform vec4 uFogColor;\n"
	"uniform float uAlphaRef;\n"
	"uniform int uAlphaFunc;\n"      // 0..7 = GL_NEVER..GL_ALWAYS
	"void main() {\n"
	"  vec4 c = vCol;\n"
	"#if USE_TEX\n"
	"  c *= texture2D(uTex, vTex);\n"
	"#endif\n"
	"#if USE_ALPHA\n"
	"  if (uAlphaFunc == 0) discard;\n"
	"  else if (uAlphaFunc == 1) { if (!(c.a <  uAlphaRef)) discard; }\n"
	"  else if (uAlphaFunc == 2) { if (!(c.a == uAlphaRef)) discard; }\n"
	"  else if (uAlphaFunc == 3) { if (!(c.a <= uAlphaRef)) discard; }\n"
	"  else if (uAlphaFunc == 4) { if (!(c.a >  uAlphaRef)) discard; }\n"
	"  else if (uAlphaFunc == 5) { if (!(c.a != uAlphaRef)) discard; }\n"
	"  else if (uAlphaFunc == 6) { if (!(c.a >= uAlphaRef)) discard; }\n"
	"#endif\n"
	"#if FOG_MODE == 1\n"
	"  float f = clamp((uFogParam.y - vFogD) / (uFogParam.y - uFogParam.x), 0.0, 1.0);\n"
	"  c.rgb = mix(uFogColor.rgb, c.rgb, f);\n"
	"#elif FOG_MODE == 2\n"
	"  float f = clamp(exp(-uFogParam.z * vFogD), 0.0, 1.0);\n"
	"  c.rgb = mix(uFogColor.rgb, c.rgb, f);\n"
	"#elif FOG_MODE == 3\n"
	"  float t = uFogParam.z * vFogD;\n"
	"  float f = clamp(exp(-t * t), 0.0, 1.0);\n"
	"  c.rgb = mix(uFogColor.rgb, c.rgb, f);\n"
	"#endif\n"
	"  gl_FragColor = c;\n"
	"}\n";

static GLuint compile_shader(GLenum type, const std::string& src) {
	GLuint s = es2_glCreateShader(type);
	const char* p = src.c_str();
	es2_glShaderSource(s, 1, &p, 0);
	es2_glCompileShader(s);
	GLint ok = 0;
	es2_glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
	if (!ok) {
		char log[2048]; GLsizei n = 0;
		es2_glGetShaderInfoLog(s, 2047, &n, log);
		log[n < 0 ? 0 : (n > 2047 ? 2047 : n)] = 0;
		fprintf(stderr, "[gles1shim] error compilando shader: %s\n", log);
		es2_glDeleteShader(s);
		return 0;
	}
	return s;
}

static GLuint link_program(GLuint vs, GLuint fs) {
	GLuint p = es2_glCreateProgram();
	es2_glAttachShader(p, vs);
	es2_glAttachShader(p, fs);
	es2_glBindAttribLocation(p, 0, "aPos");
	es2_glBindAttribLocation(p, 1, "aTex");
	es2_glBindAttribLocation(p, 2, "aCol");
	es2_glLinkProgram(p);
	GLint ok = 0;
	es2_glGetProgramiv(p, GL_LINK_STATUS, &ok);
	if (!ok) {
		char log[2048]; GLsizei n = 0;
		es2_glGetProgramInfoLog(p, 2047, &n, log);
		log[n < 0 ? 0 : (n > 2047 ? 2047 : n)] = 0;
		fprintf(stderr, "[gles1shim] error enlazando programa: %s\n", log);
		return 0;
	}
	return p;
}

static Prog* get_prog() {
	int fogMode = 0;
	if (S.fog) fogMode = (S.fogMode == GL_LINEAR) ? 1 : (S.fogMode == GL_EXP) ? 2 : 3;
	const bool useAlpha = S.alphaTest && S.alphaFunc != GL_ALWAYS;
	const int key = (S.tex2d ? 1 : 0) | (useAlpha ? 2 : 0) | (fogMode << 2);

	Prog& pr = S.prog[key];
	if (!pr.tried) {
		pr.tried = true;
		pr.ok = false;

		char defs[160];
		snprintf(defs, sizeof(defs), "#define USE_TEX %d\n#define USE_ALPHA %d\n#define FOG_MODE %d\n",
		         (key & 1) ? 1 : 0, (key & 2) ? 1 : 0, key >> 2);
		std::string fsrc = std::string(defs) + kFragmentSrc;

		GLuint vs = compile_shader(GL_VERTEX_SHADER, kVertexSrc);
		GLuint fs = compile_shader(GL_FRAGMENT_SHADER, fsrc);
		if (vs && fs) {
			pr.id = link_program(vs, fs);
			if (pr.id) {
				pr.uMVP      = es2_glGetUniformLocation(pr.id, "uMVP");
				pr.uTexMat   = es2_glGetUniformLocation(pr.id, "uTexMat");
				pr.uEyeZ     = es2_glGetUniformLocation(pr.id, "uEyeZ");
				pr.uTex      = es2_glGetUniformLocation(pr.id, "uTex");
				pr.uFogColor = es2_glGetUniformLocation(pr.id, "uFogColor");
				pr.uFogParam = es2_glGetUniformLocation(pr.id, "uFogParam");
				pr.uAlphaRef = es2_glGetUniformLocation(pr.id, "uAlphaRef");
				pr.uAlphaFunc= es2_glGetUniformLocation(pr.id, "uAlphaFunc");
				pr.ok = true;
			}
		}
		if (vs) es2_glDeleteShader(vs);
		if (fs) es2_glDeleteShader(fs);
	}
	return pr.ok ? &pr : 0;
}

static bool prepare_draw() {
	Prog* p = get_prog();
	if (!p) return false;

	es2_glUseProgram(p->id);

	float mvp[16];
	mat_mul(mvp, S.proj[S.projTop], S.mv[S.mvTop]);
	if (p->uMVP >= 0) es2_glUniformMatrix4fv(p->uMVP, 1, GL_FALSE, mvp);
	if (p->uTexMat >= 0) es2_glUniformMatrix4fv(p->uTexMat, 1, GL_FALSE, S.tex[S.texTop]);
	if (p->uEyeZ >= 0) {
		const float* m = S.mv[S.mvTop];
		es2_glUniform4f(p->uEyeZ, m[2], m[6], m[10], m[14]);
	}
	if (p->uTex >= 0) es2_glUniform1i(p->uTex, 0);
	if (p->uFogColor >= 0) es2_glUniform4f(p->uFogColor, S.fogColor[0], S.fogColor[1], S.fogColor[2], S.fogColor[3]);
	if (p->uFogParam >= 0) es2_glUniform4f(p->uFogParam, S.fogStart, S.fogEnd, S.fogDensity, 0.0f);
	if (p->uAlphaRef >= 0) es2_glUniform1f(p->uAlphaRef, S.alphaRef);
	if (p->uAlphaFunc >= 0) es2_glUniform1i(p->uAlphaFunc, (GLint)(S.alphaFunc - GL_NEVER));

	sync_attrib(0, S.vtx.enabled);
	sync_attrib(1, S.tcoord.enabled);
	if (S.col.enabled) {
		sync_attrib(2, true);
	} else {
		sync_attrib(2, false);
		es2_glVertexAttrib4f(2, S.color[0], S.color[1], S.color[2], S.color[3]);
	}
	return true;
}

static float fx(GLfixed v) { return (float)v / 65536.0f; }

} // namespace

// ---------------------------------------------------------------------------
// API publica del modulo
// ---------------------------------------------------------------------------
// Algunos drivers EGL no devuelven punteros para funciones "core" de GLES2 en
// eglGetProcAddress: en ese caso se buscan directamente en libGLESv2.
static void* shim_load(Gles1ShimLoader loader, const char* name) {
	void* p = loader(name);
	if (p) return p;
	static void* lib = 0;
	if (!lib) {
		lib = dlopen("libGLESv2.so.2", RTLD_LAZY | RTLD_LOCAL);
		if (!lib) lib = dlopen("libGLESv2.so", RTLD_LAZY | RTLD_LOCAL);
	}
	return lib ? dlsym(lib, name) : 0;
}

extern "C" int gles1shim_init(Gles1ShimLoader loader) {
	if (!loader) return 0;

	int missing = 0;
#define X(ret, name, args) \
	es2_##name = (ret (*) args) shim_load(loader, #name); \
	if (!es2_##name) { fprintf(stderr, "[gles1shim] falta la funcion GLES2: %s\n", #name); ++missing; }
	ES2_FUNCS(X)
#undef X
	if (missing) return 0;

	S.vboMap.clear();
	S.texFlags.clear();
	memset(S.mv, 0, sizeof(S.mv));
	memset(S.proj, 0, sizeof(S.proj));
	memset(S.tex, 0, sizeof(S.tex));
	S.mvTop = S.projTop = S.texTop = 0;
	mat_identity(S.mv[0]); mat_identity(S.proj[0]); mat_identity(S.tex[0]);
	S.matrixMode = GL_MODELVIEW;

	S.tex2d = false; S.alphaTest = false; S.fog = false;
	S.alphaFunc = GL_ALWAYS; S.alphaRef = 0.0f;
	S.fogMode = GL_EXP; S.fogDensity = 1.0f; S.fogStart = 0.0f; S.fogEnd = 1.0f;
	S.fogColor[0] = S.fogColor[1] = S.fogColor[2] = S.fogColor[3] = 0.0f;
	S.color[0] = S.color[1] = S.color[2] = S.color[3] = 1.0f;

	memset(&S.vtx, 0, sizeof(ArrayState));
	memset(&S.tcoord, 0, sizeof(ArrayState));
	memset(&S.col, 0, sizeof(ArrayState));
	memset(&S.nrm, 0, sizeof(ArrayState));
	S.attribOn[0] = S.attribOn[1] = S.attribOn[2] = false;

	S.capBlend = S.capDepth = S.capCull = S.capScissor = false;
	S.blendSrc = GL_ONE; S.blendDst = GL_ZERO;
	S.boundTex = 0;

	memset(S.prog, 0, sizeof(S.prog));

	S.inited = true;
	return 1;
}

extern "C" void gles1shim_shutdown(void) {
	S.inited = false;
}

// ---------------------------------------------------------------------------
// Puntos de entrada de OpenGL ES 1.1
// ---------------------------------------------------------------------------
extern "C" {

// --- matrices ---------------------------------------------------------------
void glMatrixMode(GLenum mode) { S.matrixMode = mode; }
void glLoadIdentity(void) { mat_identity(cur_mat()); }
void glLoadMatrixf(const GLfloat* m) { memcpy(cur_mat(), m, 16 * sizeof(float)); }
void glMultMatrixf(const GLfloat* m) { post_mul(m); }

void glPushMatrix(void) {
	switch (S.matrixMode) {
		case GL_PROJECTION: if (S.projTop < 7)  { memcpy(S.proj[S.projTop + 1], S.proj[S.projTop], 64); ++S.projTop; } break;
		case GL_TEXTURE:    if (S.texTop < 3)   { memcpy(S.tex[S.texTop + 1],   S.tex[S.texTop],   64); ++S.texTop;  } break;
		default:            if (S.mvTop < 31)   { memcpy(S.mv[S.mvTop + 1],     S.mv[S.mvTop],     64); ++S.mvTop;   } break;
	}
}

void glPopMatrix(void) {
	switch (S.matrixMode) {
		case GL_PROJECTION: if (S.projTop > 0) --S.projTop; break;
		case GL_TEXTURE:    if (S.texTop > 0)  --S.texTop;  break;
		default:            if (S.mvTop > 0)   --S.mvTop;   break;
	}
}

void glTranslatef(GLfloat x, GLfloat y, GLfloat z) {
	float t[16]; mat_identity(t);
	t[12] = x; t[13] = y; t[14] = z;
	post_mul(t);
}

void glScalef(GLfloat x, GLfloat y, GLfloat z) {
	float t[16]; mat_identity(t);
	t[0] = x; t[5] = y; t[10] = z;
	post_mul(t);
}

void glRotatef(GLfloat angle, GLfloat x, GLfloat y, GLfloat z) {
	float len = sqrtf(x * x + y * y + z * z);
	if (len < 1e-8f) return;
	x /= len; y /= len; z /= len;
	const float rad = angle * 3.14159265358979323846f / 180.0f;
	const float c = cosf(rad), s = sinf(rad), nc = 1.0f - c;
	float t[16]; mat_identity(t);
	t[0]  = x * x * nc + c;      t[4] = x * y * nc - z * s;  t[8]  = x * z * nc + y * s;
	t[1]  = y * x * nc + z * s;  t[5] = y * y * nc + c;      t[9]  = y * z * nc - x * s;
	t[2]  = x * z * nc - y * s;  t[6] = y * z * nc + x * s;  t[10] = z * z * nc + c;
	post_mul(t);
}

void glOrthof(GLfloat l, GLfloat r, GLfloat b, GLfloat t, GLfloat n, GLfloat f) {
	float m[16]; mat_identity(m);
	m[0]  = 2.0f / (r - l);
	m[5]  = 2.0f / (t - b);
	m[10] = -2.0f / (f - n);
	m[12] = -(r + l) / (r - l);
	m[13] = -(t + b) / (t - b);
	m[14] = -(f + n) / (f - n);
	post_mul(m);
}

void glFrustumf(GLfloat l, GLfloat r, GLfloat b, GLfloat t, GLfloat n, GLfloat f) {
	float m[16]; memset(m, 0, sizeof(m));
	m[0]  = 2.0f * n / (r - l);
	m[5]  = 2.0f * n / (t - b);
	m[8]  = (r + l) / (r - l);
	m[9]  = (t + b) / (t - b);
	m[10] = -(f + n) / (f - n);
	m[11] = -1.0f;
	m[14] = -2.0f * f * n / (f - n);
	post_mul(m);
}

void glTranslatex(GLfixed x, GLfixed y, GLfixed z) { glTranslatef(fx(x), fx(y), fx(z)); }
void glScalex(GLfixed x, GLfixed y, GLfixed z) { glScalef(fx(x), fx(y), fx(z)); }
void glRotatex(GLfixed a, GLfixed x, GLfixed y, GLfixed z) { glRotatef(fx(a), fx(x), fx(y), fx(z)); }
void glOrthox(GLfixed l, GLfixed r, GLfixed b, GLfixed t, GLfixed n, GLfixed f) { glOrthof(fx(l), fx(r), fx(b), fx(t), fx(n), fx(f)); }
void glFrustumx(GLfixed l, GLfixed r, GLfixed b, GLfixed t, GLfixed n, GLfixed f) { glFrustumf(fx(l), fx(r), fx(b), fx(t), fx(n), fx(f)); }

// --- capacidades ------------------------------------------------------------
void glEnable(GLenum cap) {
	switch (cap) {
		case GL_TEXTURE_2D: S.tex2d = true; break;
		case GL_ALPHA_TEST: S.alphaTest = true; break;
		case GL_FOG:        S.fog = true; break;
		case GL_BLEND:      S.capBlend = true;   es2_glEnable(cap); break;
		case GL_DEPTH_TEST: S.capDepth = true;   es2_glEnable(cap); break;
		case GL_CULL_FACE:  S.capCull = true;    es2_glEnable(cap); break;
		case GL_SCISSOR_TEST: S.capScissor = true; es2_glEnable(cap); break;
		case GL_POLYGON_OFFSET_FILL:
		case GL_DITHER:
		case GL_STENCIL_TEST:
		case GL_SAMPLE_ALPHA_TO_COVERAGE:
		case GL_SAMPLE_COVERAGE:
			es2_glEnable(cap); break;
		default: break; // iluminacion, normalizacion, etc.: no se emulan
	}
}

void glDisable(GLenum cap) {
	switch (cap) {
		case GL_TEXTURE_2D: S.tex2d = false; break;
		case GL_ALPHA_TEST: S.alphaTest = false; break;
		case GL_FOG:        S.fog = false; break;
		case GL_BLEND:      S.capBlend = false;   es2_glDisable(cap); break;
		case GL_DEPTH_TEST: S.capDepth = false;   es2_glDisable(cap); break;
		case GL_CULL_FACE:  S.capCull = false;    es2_glDisable(cap); break;
		case GL_SCISSOR_TEST: S.capScissor = false; es2_glDisable(cap); break;
		case GL_POLYGON_OFFSET_FILL:
		case GL_DITHER:
		case GL_STENCIL_TEST:
		case GL_SAMPLE_ALPHA_TO_COVERAGE:
		case GL_SAMPLE_COVERAGE:
			es2_glDisable(cap); break;
		default: break;
	}
}

GLboolean glIsEnabled(GLenum cap) {
	switch (cap) {
		case GL_TEXTURE_2D: return S.tex2d ? GL_TRUE : GL_FALSE;
		case GL_ALPHA_TEST: return S.alphaTest ? GL_TRUE : GL_FALSE;
		case GL_FOG:        return S.fog ? GL_TRUE : GL_FALSE;
		case GL_LIGHTING: case GL_COLOR_MATERIAL: case GL_RESCALE_NORMAL: case GL_NORMALIZE: return GL_FALSE;
		default: return es2_glIsEnabled(cap);
	}
}

void glEnableClientState(GLenum array) {
	switch (array) {
		case GL_VERTEX_ARRAY:        S.vtx.enabled = true; break;
		case GL_TEXTURE_COORD_ARRAY: S.tcoord.enabled = true; break;
		case GL_COLOR_ARRAY:         S.col.enabled = true; break;
		case GL_NORMAL_ARRAY:        S.nrm.enabled = true; break;
		default: break;
	}
}

void glDisableClientState(GLenum array) {
	switch (array) {
		case GL_VERTEX_ARRAY:        S.vtx.enabled = false; break;
		case GL_TEXTURE_COORD_ARRAY: S.tcoord.enabled = false; break;
		case GL_COLOR_ARRAY:         S.col.enabled = false; break;
		case GL_NORMAL_ARRAY:        S.nrm.enabled = false; break;
		default: break;
	}
}

void glClientActiveTexture(GLenum) {}
void glActiveTexture(GLenum texture) { es2_glActiveTexture(texture); }

// --- punteros de vertices ---------------------------------------------------
void glVertexPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr) {
	S.vtx.size = size; S.vtx.type = type; S.vtx.stride = stride; S.vtx.ptr = ptr;
	es2_glVertexAttribPointer(0, size, type, GL_FALSE, stride, ptr);
}

void glTexCoordPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr) {
	S.tcoord.size = size; S.tcoord.type = type; S.tcoord.stride = stride; S.tcoord.ptr = ptr;
	es2_glVertexAttribPointer(1, size, type, GL_FALSE, stride, ptr);
}

void glColorPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr) {
	S.col.size = size; S.col.type = type; S.col.stride = stride; S.col.ptr = ptr;
	es2_glVertexAttribPointer(2, size, type, (type == GL_UNSIGNED_BYTE) ? GL_TRUE : GL_FALSE, stride, ptr);
}

void glNormalPointer(GLenum type, GLsizei stride, const GLvoid* ptr) {
	S.nrm.type = type; S.nrm.stride = stride; S.nrm.ptr = ptr; // sin iluminacion: no se usa
}

// --- color ------------------------------------------------------------------
void glColor4f(GLfloat r, GLfloat g, GLfloat b, GLfloat a) {
	S.color[0] = r; S.color[1] = g; S.color[2] = b; S.color[3] = a;
}
void glColor4ub(GLubyte r, GLubyte g, GLubyte b, GLubyte a) {
	glColor4f(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f);
}
void glColor4x(GLfixed r, GLfixed g, GLfixed b, GLfixed a) { glColor4f(fx(r), fx(g), fx(b), fx(a)); }

// --- alpha test / niebla ----------------------------------------------------
void glAlphaFunc(GLenum func, GLclampf ref) { S.alphaFunc = func; S.alphaRef = ref; }
void glAlphaFuncx(GLenum func, GLclampx ref) { S.alphaFunc = func; S.alphaRef = fx(ref); }

static void fog_param(GLenum pname, float v) {
	switch (pname) {
		case GL_FOG_MODE:    S.fogMode = (GLenum)(int)v; break;
		case GL_FOG_DENSITY: S.fogDensity = v; break;
		case GL_FOG_START:   S.fogStart = v; break;
		case GL_FOG_END:     S.fogEnd = v; break;
		default: break;
	}
}

void glFogf(GLenum pname, GLfloat param) { fog_param(pname, param); }
void glFogfv(GLenum pname, const GLfloat* params) {
	if (pname == GL_FOG_COLOR) {
		S.fogColor[0] = params[0]; S.fogColor[1] = params[1];
		S.fogColor[2] = params[2]; S.fogColor[3] = params[3];
	} else {
		fog_param(pname, params[0]);
	}
}
void glFogx(GLenum pname, GLfixed param) {
	if (pname == GL_FOG_MODE) S.fogMode = (GLenum)param;   // enum, no es punto fijo
	else fog_param(pname, fx(param));
}
void glFogxv(GLenum pname, const GLfixed* params) {
	if (pname == GL_FOG_COLOR) {
		S.fogColor[0] = fx(params[0]); S.fogColor[1] = fx(params[1]);
		S.fogColor[2] = fx(params[2]); S.fogColor[3] = fx(params[3]);
	} else {
		glFogx(pname, params[0]);
	}
}

// --- cosas de la tuberia fija que no se emulan (se aceptan y se ignoran) -----
void glShadeModel(GLenum) {}
void glHint(GLenum, GLenum) {}
void glNormal3f(GLfloat, GLfloat, GLfloat) {}
void glLightModelf(GLenum, GLfloat) {}
void glLightModelfv(GLenum, const GLfloat*) {}
void glLightf(GLenum, GLenum, GLfloat) {}
void glLightfv(GLenum, GLenum, const GLfloat*) {}
void glMaterialf(GLenum, GLenum, GLfloat) {}
void glMaterialfv(GLenum, GLenum, const GLfloat*) {}
void glTexEnvf(GLenum, GLenum, GLfloat) {}
void glTexEnvi(GLenum, GLenum, GLint) {}
void glTexEnvfv(GLenum, GLenum, const GLfloat*) {}
void glTexEnviv(GLenum, GLenum, const GLint*) {}
void glMultiTexCoord4f(GLenum, GLfloat, GLfloat, GLfloat, GLfloat) {}
void glPointSize(GLfloat) {}
void glLogicOp(GLenum) {}
void glClipPlanef(GLenum, const GLfloat*) {}

// --- estado que pasa directo a GLES2 ----------------------------------------
void glBlendFunc(GLenum sfactor, GLenum dfactor) {
	S.blendSrc = sfactor; S.blendDst = dfactor;
	es2_glBlendFunc(sfactor, dfactor);
}
void glClear(GLbitfield mask) { es2_glClear(mask); }
void glClearColor(GLclampf r, GLclampf g, GLclampf b, GLclampf a) { es2_glClearColor(r, g, b, a); }
void glClearDepthf(GLclampf d) { es2_glClearDepthf(d); }
void glColorMask(GLboolean r, GLboolean g, GLboolean b, GLboolean a) { es2_glColorMask(r, g, b, a); }
void glCullFace(GLenum mode) { es2_glCullFace(mode); }
void glFrontFace(GLenum mode) { es2_glFrontFace(mode); }
void glDepthFunc(GLenum func) { es2_glDepthFunc(func); }
void glDepthMask(GLboolean flag) { es2_glDepthMask(flag); }
void glDepthRangef(GLclampf n, GLclampf f) { es2_glDepthRangef(n, f); }
void glLineWidth(GLfloat w) { es2_glLineWidth(w); }
void glPolygonOffset(GLfloat factor, GLfloat units) { es2_glPolygonOffset(factor, units); }
void glScissor(GLint x, GLint y, GLsizei w, GLsizei h) { es2_glScissor(x, y, w, h); }
void glViewport(GLint x, GLint y, GLsizei w, GLsizei h) { es2_glViewport(x, y, w, h); }
void glPixelStorei(GLenum pname, GLint param) { es2_glPixelStorei(pname, param); }
void glFinish(void) { es2_glFinish(); }
void glFlush(void) { es2_glFlush(); }
GLenum glGetError(void) { return es2_glGetError(); }
const GLubyte* glGetString(GLenum name) { return es2_glGetString(name); }
void glReadPixels(GLint x, GLint y, GLsizei w, GLsizei h, GLenum format, GLenum type, GLvoid* pixels) {
	es2_glReadPixels(x, y, w, h, format, type, pixels);
}

void glGetFloatv(GLenum pname, GLfloat* params) {
	switch (pname) {
		case GL_MODELVIEW_MATRIX:  memcpy(params, S.mv[S.mvTop],     64); break;
		case GL_PROJECTION_MATRIX: memcpy(params, S.proj[S.projTop], 64); break;
		case GL_TEXTURE_MATRIX:    memcpy(params, S.tex[S.texTop],   64); break;
		default: es2_glGetFloatv(pname, params); break;
	}
}

void glGetIntegerv(GLenum pname, GLint* params) {
	switch (pname) {
		case SHIM_MATRIX_MODE: *params = (GLint)S.matrixMode; break;
		default: es2_glGetIntegerv(pname, params); break;
	}
}

// --- texturas ----------------------------------------------------------------
void glGenTextures(GLsizei n, GLuint* textures) { es2_glGenTextures(n, textures); }

void glBindTexture(GLenum target, GLuint texture) {
	S.boundTex = texture;
	es2_glBindTexture(target, texture);
}

void glDeleteTextures(GLsizei n, const GLuint* textures) {
	for (GLsizei i = 0; i < n; ++i) S.texFlags.erase(textures[i]);
	es2_glDeleteTextures(n, textures);
}

void glTexParameteri(GLenum target, GLenum pname, GLint param) {
	if (pname == GL_GENERATE_MIPMAP) {            // GLES1: mipmaps automaticos
		if (param) S.texFlags[S.boundTex] |= 1; else S.texFlags[S.boundTex] &= ~1;
		return;
	}
	if (pname == GL_TEXTURE_MIN_FILTER) {
		const bool mip = (param >= 0x2700 && param <= 0x2703);
		if (mip) S.texFlags[S.boundTex] |= 1;
	}
	es2_glTexParameteri(target, pname, param);
}
void glTexParameterx(GLenum target, GLenum pname, GLfixed param) { glTexParameteri(target, pname, (GLint)param); }
void glTexParameterf(GLenum target, GLenum pname, GLfloat param) { glTexParameteri(target, pname, (GLint)param); }

static bool wants_mips() {
	std::map<GLuint, int>::const_iterator it = S.texFlags.find(S.boundTex);
	return it != S.texFlags.end() && (it->second & 1);
}

void glTexImage2D(GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height,
                  GLint border, GLenum format, GLenum type, const GLvoid* pixels) {
	es2_glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels);
	if (level == 0 && pixels && wants_mips()) es2_glGenerateMipmap(target);
}

void glTexSubImage2D(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height,
                     GLenum format, GLenum type, const GLvoid* pixels) {
	es2_glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
	if (level == 0 && wants_mips()) es2_glGenerateMipmap(target);
}

// --- buffers -----------------------------------------------------------------
// El juego genera sus propios ids (anGenBuffers) y los enlaza sin glGenBuffers:
// los traducimos a ids reales para no depender de que el driver lo tolere.
void glGenBuffers(GLsizei n, GLuint* buffers) { es2_glGenBuffers(n, buffers); }

void glBindBuffer(GLenum target, GLuint buffer) {
	GLuint real = 0;
	if (buffer != 0) {
		std::map<GLuint, GLuint>::iterator it = S.vboMap.find(buffer);
		if (it == S.vboMap.end()) {
			GLuint id = 0;
			es2_glGenBuffers(1, &id);
			it = S.vboMap.insert(std::make_pair(buffer, id)).first;
		}
		real = it->second;
	}
	es2_glBindBuffer(target, real);
}

void glBufferData(GLenum target, GLsizeiptr size, const GLvoid* data, GLenum usage) {
	es2_glBufferData(target, size, data, usage);
}
void glBufferSubData(GLenum target, GLintptr offset, GLsizeiptr size, const GLvoid* data) {
	es2_glBufferSubData(target, offset, size, data);
}

void glDeleteBuffers(GLsizei n, const GLuint* buffers) {
	for (GLsizei i = 0; i < n; ++i) {
		std::map<GLuint, GLuint>::iterator it = S.vboMap.find(buffers[i]);
		if (it != S.vboMap.end()) {
			GLuint real = it->second;
			es2_glDeleteBuffers(1, &real);
			S.vboMap.erase(it);
		}
	}
}

// --- dibujo ------------------------------------------------------------------
void glDrawArrays(GLenum mode, GLint first, GLsizei count) {
	if (!S.vtx.enabled || count <= 0) return;
	if (mode == 0x0007) mode = GL_TRIANGLES; // GL_QUADS no existe en ES2 (el juego ya triangula)
	if (!prepare_draw()) return;
	es2_glDrawArrays(mode, first, count);
}

void glDrawElements(GLenum mode, GLsizei count, GLenum type, const GLvoid* indices) {
	if (!S.vtx.enabled || count <= 0) return;
	if (!prepare_draw()) return;
	es2_glDrawElements(mode, count, type, indices);
}

} // extern "C"
