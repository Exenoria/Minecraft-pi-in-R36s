#ifndef MAIN_SDL2_H__
#define MAIN_SDL2_H__

/*
 * Capa de plataforma SDL2 para la consola R36S (aarch64, 640x480, mando).
 *
 * Reemplaza a main_rpi.h (que usaba bcm_host/DispmanX/EGL de la Raspberry Pi y SDL 1.2):
 *   - Ventana + contexto OpenGL ES 2.0 con SDL2 (KMSDRM en la consola, X11/Wayland en PC)
 *   - OpenGL ES 1.1 emulado sobre ES 2.0 con gles1_shim.cpp
 *   - Mando (SDL_GameController): sticks, gatillos, cruceta y botones -> teclas/raton del juego
 *   - Cursor de menu: lo dibuja el propio juego (renderCursor) en la posicion que le pasamos
 *
 * Controles en juego (nombres SDL; "swap_ab"/"swap_xy" en controls.cfg los intercambia):
 *   Stick izq: mover        Stick der: mirar
 *   R2: romper/atacar       L2: colocar/usar
 *   A: saltar (2 veces = volar)   B: agacharse / bajar volando
 *   X: inventario           L1/R1 o cruceta izq/der: ranura anterior/siguiente
 *   Start: pausa            Select+Start: salir del juego
 * En menus: cruceta arriba/abajo + A = navegar y aceptar; mover un stick activa
 * el cursor (A = clic); B = atras.
 */

#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

#include <png.h>
#include <setjmp.h>

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>

#include <unistd.h>
#include <sys/stat.h>

#include "App.h"
#include "world/level/Level.h"
#include "platform/input/Mouse.h"
#include "platform/input/Multitouch.h"
#include "platform/input/Keyboard.h"
#include "gles1_shim.h"

#include <GLES/gl.h>

// ---------------------------------------------------------------------------
// Estado global de la plataforma
// ---------------------------------------------------------------------------
static SDL_Window*         g_window = NULL;
static SDL_GLContext       g_glctx = NULL;
static SDL_GameController* g_pad = NULL;

static int   g_width = 640;
static int   g_height = 480;
static bool  g_mouseGrabbed = true;   // lo cambia MouseHandler::grab()/release()
static bool  g_quit = false;
static bool  g_cursorActive = false;  // cursor de menu visible/en uso
static float g_curX = 320.0f;
static float g_curY = 240.0f;

struct R36SConfig {
	float lookSpeed;    // pixeles/segundo con el stick derecho a fondo
	float cursorSpeed;  // idem para el cursor de los menus
	float deadzone;
	bool  swapAB, swapXY;
	bool  windowed;
	int   viewDistance;  // -1 = la que trae el juego (2); 0 lejos, 1 normal, 2 corta, 3 minima
	R36SConfig()
	:	lookSpeed(900.0f), cursorSpeed(480.0f), deadzone(0.20f),
		swapAB(false), swapXY(false), windowed(false), viewDistance(-1) {}
};
static R36SConfig g_cfg;

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
static std::string trimStr(const std::string& s) {
	size_t a = 0, b = s.size();
	while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r' || s[a] == '\n')) ++a;
	while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r' || s[b - 1] == '\n')) --b;
	return s.substr(a, b - a);
}

static void loadConfig(const char* path) {
	std::ifstream f(path);
	if (!f) return;
	std::string line;
	while (std::getline(f, line)) {
		size_t h = line.find('#');
		if (h != std::string::npos) line = line.substr(0, h);
		size_t eq = line.find('=');
		if (eq == std::string::npos) continue;
		const std::string k = trimStr(line.substr(0, eq));
		const std::string v = trimStr(line.substr(eq + 1));
		if (k == "look_speed")   g_cfg.lookSpeed = (float)atof(v.c_str());
		if (k == "cursor_speed") g_cfg.cursorSpeed = (float)atof(v.c_str());
		if (k == "deadzone")     g_cfg.deadzone = (float)atof(v.c_str());
		if (k == "swap_ab")      g_cfg.swapAB = atoi(v.c_str()) != 0;
		if (k == "swap_xy")      g_cfg.swapXY = atoi(v.c_str()) != 0;
		if (k == "windowed")     g_cfg.windowed = atoi(v.c_str()) != 0;
		if (k == "view_distance") g_cfg.viewDistance = atoi(v.c_str());
	}
	if (g_cfg.lookSpeed < 50.0f) g_cfg.lookSpeed = 50.0f;
	if (g_cfg.cursorSpeed < 50.0f) g_cfg.cursorSpeed = 50.0f;
	if (g_cfg.deadzone < 0.02f) g_cfg.deadzone = 0.02f;
	if (g_cfg.deadzone > 0.6f) g_cfg.deadzone = 0.6f;
}

static bool fileExists(const std::string& p) {
	struct stat st;
	return stat(p.c_str(), &st) == 0;
}

static void makeDirs(const std::string& path) {
	std::string cur;
	for (size_t i = 0; i < path.size(); ++i) {
		cur += path[i];
		if (path[i] == '/' && cur.size() > 1) mkdir(cur.c_str(), 0755);
	}
	mkdir(path.c_str(), 0755);
}

// ---------------------------------------------------------------------------
// Plataforma: carga de texturas PNG
// ---------------------------------------------------------------------------
static void png_funcReadFile(png_structp pngPtr, png_bytep data, png_size_t length) {
	((std::istream*)png_get_io_ptr(pngPtr))->read((char*)data, length);
}

class AppPlatform_linux: public AppPlatform
{
public:
	bool isTouchscreen() { return false; }
	int getScreenWidth() { return g_width; }
	int getScreenHeight() { return g_height; }

	TextureData loadTexture(const std::string& filename_, bool textureFolder)
	{
		TextureData out;

		std::string filename = textureFolder ? "data/images/" + filename_ : filename_;
		std::ifstream source(filename.c_str(), std::ios::binary);
		if (!source) {
			LOGI("Couldn't find file: %s\n", filename.c_str());
			return out;
		}

		png_structp pngPtr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
		if (!pngPtr) return out;
		png_infop infoPtr = png_create_info_struct(pngPtr);
		if (!infoPtr) {
			png_destroy_read_struct(&pngPtr, NULL, NULL);
			return out;
		}

		unsigned char* volatile data = NULL;
		png_bytep* volatile rowPtrs = NULL;
		if (setjmp(png_jmpbuf(pngPtr))) {
			png_destroy_read_struct(&pngPtr, &infoPtr, NULL);
			delete[] data;
			delete[] rowPtrs;
			LOGI("PNG corrupto: %s\n", filename.c_str());
			return TextureData();
		}

		png_set_read_fn(pngPtr, (void*)&source, png_funcReadFile);
		png_read_info(pngPtr, infoPtr);

		// Siempre RGBA de 8 bits por canal, sea cual sea el PNG original
		const int colorType = png_get_color_type(pngPtr, infoPtr);
		const int bitDepth = png_get_bit_depth(pngPtr, infoPtr);
		if (bitDepth == 16) png_set_strip_16(pngPtr);
		if (colorType == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(pngPtr);
		if (colorType == PNG_COLOR_TYPE_GRAY && bitDepth < 8) png_set_expand_gray_1_2_4_to_8(pngPtr);
		if (png_get_valid(pngPtr, infoPtr, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(pngPtr);
		if (colorType == PNG_COLOR_TYPE_GRAY || colorType == PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(pngPtr);
		if (colorType == PNG_COLOR_TYPE_RGB || colorType == PNG_COLOR_TYPE_GRAY || colorType == PNG_COLOR_TYPE_PALETTE)
			png_set_filler(pngPtr, 0xFF, PNG_FILLER_AFTER);
		png_set_interlace_handling(pngPtr);
		png_read_update_info(pngPtr, infoPtr);

		out.w = (int)png_get_image_width(pngPtr, infoPtr);
		out.h = (int)png_get_image_height(pngPtr, infoPtr);

		rowPtrs = new png_bytep[out.h];
		data = new unsigned char[4 * out.w * out.h];
		const int rowStrideBytes = 4 * out.w;
		for (int i = 0; i < out.h; i++)
			rowPtrs[i] = (png_bytep)&data[i * rowStrideBytes];
		png_read_image(pngPtr, rowPtrs);

		png_destroy_read_struct(&pngPtr, &infoPtr, (png_infopp)0);
		delete[] rowPtrs;
		source.close();

		out.data = data;
		out.memoryHandledExternally = false;
		return out;
	}
};

// ---------------------------------------------------------------------------
// Entrada: teclado/raton "virtuales" del juego
// ---------------------------------------------------------------------------
static bool g_keyHeld[256];

static void setKey(int key, bool down) {
	if (key < 0 || key > 255) return;
	if (g_keyHeld[key] == down) return;
	g_keyHeld[key] = down;
	Keyboard::feed((unsigned char)key, down ? 1 : 0);
}

static void tapKey(int key) {
	Keyboard::feed((unsigned char)key, 1);
	Keyboard::feed((unsigned char)key, 0);
}

static void releaseAllHeldKeys() {
	for (int k = 0; k < 256; ++k) setKey(k, false);
}

static void feedMouseMove(float x, float y, int dx, int dy) {
	Multitouch::feed(0, 0, (short)x, (short)y, 0);
	Mouse::feed(0, 0, (short)x, (short)y, (short)dx, (short)dy);
}

static void feedMouseButton(int button /* 1 izq, 2 der */, bool down, float x, float y) {
	Mouse::feed((char)button, down ? 1 : 0, (short)x, (short)y);
	Multitouch::feed((char)button, down ? 1 : 0, (short)x, (short)y, 0);
}

static void feedWheel(int dy) {
	Mouse::feed(3, 0, (short)(g_width / 2), (short)(g_height / 2), 0, (short)dy);
}

// Gancho: lo llama MouseHandler::grab()/release() (el juego entra/sale de un menu)
void r36s_setMouseGrab(bool grab) {
	g_mouseGrabbed = grab;
	if (grab) g_cursorActive = false;
	SDL_SetRelativeMouseMode(grab ? SDL_TRUE : SDL_FALSE); // solo importa con un raton real (PC)
}

// ---------------------------------------------------------------------------
// Mando
// ---------------------------------------------------------------------------
enum {
	PB_A, PB_B, PB_X, PB_Y, PB_BACK, PB_START, PB_L1, PB_R1,
	PB_DU, PB_DD, PB_DL, PB_DR, PB_L3, PB_R3, PB_COUNT
};

struct PadInput {
	float lx, ly, rx, ry, lt, rt;
	bool  btn[PB_COUNT];
};

static float padAxis(SDL_GameController* c, SDL_GameControllerAxis a) {
	return (float)SDL_GameControllerGetAxis(c, a) / 32767.0f;
}

static bool padBtn(SDL_GameController* c, SDL_GameControllerButton b) {
	return SDL_GameControllerGetButton(c, b) != 0;
}

static void readPad(PadInput& p) {
	memset(&p, 0, sizeof(p));
	if (!g_pad) return;
	SDL_GameController* c = g_pad;

	p.lx = padAxis(c, SDL_CONTROLLER_AXIS_LEFTX);
	p.ly = padAxis(c, SDL_CONTROLLER_AXIS_LEFTY);
	p.rx = padAxis(c, SDL_CONTROLLER_AXIS_RIGHTX);
	p.ry = padAxis(c, SDL_CONTROLLER_AXIS_RIGHTY);
	p.lt = padAxis(c, SDL_CONTROLLER_AXIS_TRIGGERLEFT);
	p.rt = padAxis(c, SDL_CONTROLLER_AXIS_TRIGGERRIGHT);

	const SDL_GameControllerButton bA = g_cfg.swapAB ? SDL_CONTROLLER_BUTTON_B : SDL_CONTROLLER_BUTTON_A;
	const SDL_GameControllerButton bB = g_cfg.swapAB ? SDL_CONTROLLER_BUTTON_A : SDL_CONTROLLER_BUTTON_B;
	const SDL_GameControllerButton bX = g_cfg.swapXY ? SDL_CONTROLLER_BUTTON_Y : SDL_CONTROLLER_BUTTON_X;
	const SDL_GameControllerButton bY = g_cfg.swapXY ? SDL_CONTROLLER_BUTTON_X : SDL_CONTROLLER_BUTTON_Y;

	p.btn[PB_A] = padBtn(c, bA);
	p.btn[PB_B] = padBtn(c, bB);
	p.btn[PB_X] = padBtn(c, bX);
	p.btn[PB_Y] = padBtn(c, bY);
	p.btn[PB_BACK]  = padBtn(c, SDL_CONTROLLER_BUTTON_BACK);
	p.btn[PB_START] = padBtn(c, SDL_CONTROLLER_BUTTON_START);
	p.btn[PB_L1] = padBtn(c, SDL_CONTROLLER_BUTTON_LEFTSHOULDER);
	p.btn[PB_R1] = padBtn(c, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER);
	p.btn[PB_DU] = padBtn(c, SDL_CONTROLLER_BUTTON_DPAD_UP);
	p.btn[PB_DD] = padBtn(c, SDL_CONTROLLER_BUTTON_DPAD_DOWN);
	p.btn[PB_DL] = padBtn(c, SDL_CONTROLLER_BUTTON_DPAD_LEFT);
	p.btn[PB_DR] = padBtn(c, SDL_CONTROLLER_BUTTON_DPAD_RIGHT);
	p.btn[PB_L3] = padBtn(c, SDL_CONTROLLER_BUTTON_LEFTSTICK);
	p.btn[PB_R3] = padBtn(c, SDL_CONTROLLER_BUTTON_RIGHTSTICK);
}

static float applyDead(float v) {
	const float a = fabsf(v);
	if (a < g_cfg.deadzone) return 0.0f;
	float s = (a - g_cfg.deadzone) / (1.0f - g_cfg.deadzone);
	if (s > 1.0f) s = 1.0f;
	return v < 0.0f ? -s : s;
}

// curva de respuesta: fina cerca del centro, rapida a fondo
static float curve(float v) {
	const float a = fabsf(v);
	const float s = a * (0.35f + 0.65f * a);
	return v < 0.0f ? -s : s;
}

// movimiento digital con histeresis
static bool hyst(bool wasOn, float v) {
	return wasOn ? (v > 0.30f) : (v > 0.50f);
}

static void applyPad(const PadInput& p, float dt)
{
	static PadInput prev;
	static bool havePrev = false;
	static bool prevMenu = false;
	static bool mvF = false, mvB = false, mvL = false, mvR = false;
	static bool clickHeld = false;
	static bool leftBtn = false, rightBtn = false;
	static float accX = 0.0f, accY = 0.0f;

	if (!havePrev) { memset(&prev, 0, sizeof(prev)); havePrev = true; }

	const bool menu = !g_mouseGrabbed;

	if (p.btn[PB_BACK] && p.btn[PB_START]) g_quit = true;

	if (menu != prevMenu) {
		// cambio menu <-> juego: soltar todo para que no queden teclas "pegadas"
		releaseAllHeldKeys();
		mvF = mvB = mvL = mvR = false;
		if (leftBtn)  { feedMouseButton(1, false, g_width / 2.0f, g_height / 2.0f); leftBtn = false; }
		if (rightBtn) { feedMouseButton(2, false, g_width / 2.0f, g_height / 2.0f); rightBtn = false; }
		accX = accY = 0.0f;
		if (menu) feedMouseMove(g_curX, g_curY, 0, 0); // el juego dibuja su cursor aqui
		prevMenu = menu;
	}

#define PRESSED(b)  (p.btn[b] && !prev.btn[b])
#define RELEASED(b) (!p.btn[b] && prev.btn[b])

	if (!menu) {
		// ---------------- en juego ----------------
		const float lx = applyDead(p.lx), ly = applyDead(p.ly);

		mvF = hyst(mvF, -ly);
		mvB = hyst(mvB,  ly);
		mvL = hyst(mvL, -lx);
		mvR = hyst(mvR,  lx);
		setKey(Keyboard::KEY_W, mvF);
		setKey(Keyboard::KEY_S, mvB);
		setKey(Keyboard::KEY_A, mvL);
		setKey(Keyboard::KEY_D, mvR);

		setKey(Keyboard::KEY_SPACE, p.btn[PB_A]);      // saltar / subir volando
		setKey(Keyboard::KEY_LSHIFT, p.btn[PB_B]);     // agacharse / bajar volando

		if (PRESSED(PB_X)) tapKey(Keyboard::KEY_E);    // inventario
		if (PRESSED(PB_START)) tapKey(Keyboard::KEY_ESCAPE); // pausa

		if (PRESSED(PB_L1) || PRESSED(PB_DL)) feedWheel(1);   // ranura anterior
		if (PRESSED(PB_R1) || PRESSED(PB_DR)) feedWheel(-1);  // ranura siguiente

		// gatillos -> botones del raton (romper / usar)
		const bool wantLeft  = p.rt > 0.5f;
		const bool wantRight = p.lt > 0.5f;
		const float cx = g_width / 2.0f, cy = g_height / 2.0f;
		if (wantLeft != leftBtn)   { feedMouseButton(1, wantLeft,  cx, cy); leftBtn = wantLeft; }
		if (wantRight != rightBtn) { feedMouseButton(2, wantRight, cx, cy); rightBtn = wantRight; }

		// stick derecho -> giro de camara (movimiento relativo del "raton")
		const float rx = curve(applyDead(p.rx)), ry = curve(applyDead(p.ry));
		accX += rx * g_cfg.lookSpeed * dt;
		accY += ry * g_cfg.lookSpeed * dt;
		const int dx = (int)accX, dy = (int)accY;
		accX -= (float)dx;
		accY -= (float)dy;
		if (dx != 0 || dy != 0) feedMouseMove(cx, cy, dx, dy);
	}
	else {
		// ---------------- en menus ----------------
		float mx = applyDead(p.rx) + applyDead(p.lx);
		float my = applyDead(p.ry) + applyDead(p.ly);
		if (mx > 1.0f) mx = 1.0f; if (mx < -1.0f) mx = -1.0f;
		if (my > 1.0f) my = 1.0f; if (my < -1.0f) my = -1.0f;

		if (mx != 0.0f || my != 0.0f) {
			g_cursorActive = true;
			const float oldX = g_curX, oldY = g_curY;
			g_curX += curve(mx) * g_cfg.cursorSpeed * dt;
			g_curY += curve(my) * g_cfg.cursorSpeed * dt;
			if (g_curX < 0.0f) g_curX = 0.0f;
			if (g_curY < 0.0f) g_curY = 0.0f;
			if (g_curX > (float)(g_width - 1)) g_curX = (float)(g_width - 1);
			if (g_curY > (float)(g_height - 1)) g_curY = (float)(g_height - 1);
			feedMouseMove(g_curX, g_curY, (int)(g_curX - oldX), (int)(g_curY - oldY));
		}

		if (PRESSED(PB_DU)) { g_cursorActive = false; tapKey(38); }
		if (PRESSED(PB_DD)) { g_cursorActive = false; tapKey(40); }

		if (PRESSED(PB_A)) {
			if (g_cursorActive) { feedMouseButton(1, true, g_curX, g_curY); clickHeld = true; }
			else tapKey(13); // Enter
		}
		if (RELEASED(PB_A) && clickHeld) { feedMouseButton(1, false, g_curX, g_curY); clickHeld = false; }

		if (PRESSED(PB_B)) tapKey(Keyboard::KEY_ESCAPE);      // atras
		if (PRESSED(PB_START)) tapKey(Keyboard::KEY_ESCAPE);
		if (PRESSED(PB_X)) tapKey(Keyboard::KEY_E);           // cierra el inventario
	}

#undef PRESSED
#undef RELEASED

	prev = p;
}

static void openFirstPad() {
	if (g_pad) return;
	const int n = SDL_NumJoysticks();
	for (int i = 0; i < n; ++i) {
		if (SDL_IsGameController(i)) {
			g_pad = SDL_GameControllerOpen(i);
			if (g_pad) {
				LOGI("Mando abierto: %s\n", SDL_GameControllerName(g_pad));
				return;
			}
		}
	}
	if (n > 0) LOGI("Hay %d joystick(s) pero ninguno tiene mapeo de mando (revisa SDL_GAMECONTROLLERCONFIG)\n", n);
}

// ---------------------------------------------------------------------------
// Teclado / raton reales (USB, o PC para pruebas)
// ---------------------------------------------------------------------------
static unsigned char transformKey(int key) {
	// Si no se maneja -> 0 ("invalida")
	if (key == SDLK_LSHIFT || key == SDLK_RSHIFT) return Keyboard::KEY_LSHIFT;
	if (key == SDLK_DOWN) return 40;
	if (key == SDLK_UP)   return 38;
	if (key == SDLK_SPACE) return Keyboard::KEY_SPACE;
	if (key == SDLK_RETURN) return 13;
	if (key == SDLK_BACKSPACE) return 8;
	if (key == SDLK_ESCAPE) return Keyboard::KEY_ESCAPE;
	if (key == SDLK_TAB) return 250;
	if (key >= 'a' && key <= 'z') return (unsigned char)(key - 32);
	if (key >= SDLK_0 && key <= SDLK_9) return (unsigned char)('0' + (key - SDLK_0));
	return 0;
}

static int handleEvents() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
			return -1;
		case SDL_KEYDOWN:
			if (!event.key.repeat) {
				unsigned char t = transformKey(event.key.keysym.sym);
				if (t) Keyboard::feed(t, 1);
			}
			break;
		case SDL_KEYUP: {
			unsigned char t = transformKey(event.key.keysym.sym);
			if (t) Keyboard::feed(t, 0);
			break;
		}
		case SDL_MOUSEBUTTONDOWN:
		case SDL_MOUSEBUTTONUP: {
			const bool down = (event.type == SDL_MOUSEBUTTONDOWN);
			const bool left = (event.button.button == SDL_BUTTON_LEFT);
			feedMouseButton(left ? 1 : 2, down, (float)event.button.x, (float)event.button.y);
			break;
		}
		case SDL_MOUSEMOTION:
			feedMouseMove((float)event.motion.x, (float)event.motion.y, event.motion.xrel, event.motion.yrel);
			break;
		case SDL_MOUSEWHEEL:
			if (event.wheel.y > 0) feedWheel(1);
			else if (event.wheel.y < 0) feedWheel(-1);
			break;
		case SDL_CONTROLLERDEVICEADDED:
			openFirstPad();
			break;
		case SDL_CONTROLLERDEVICEREMOVED:
			if (g_pad && !SDL_GameControllerGetAttached(g_pad)) {
				SDL_GameControllerClose(g_pad);
				g_pad = NULL;
				LOGI("Mando desconectado\n");
			}
			break;
		default:
			break;
		}
	}
	return 0;
}

// ---------------------------------------------------------------------------
// Cursor de los menus + intercambio de buffers
// ---------------------------------------------------------------------------
#ifdef R36S_AUTOTEST
static std::string g_shotRequest;
static void saveScreenshotPNG(const std::string& path) {
	std::vector<unsigned char> px((size_t)g_width * g_height * 4);
	glReadPixels(0, 0, g_width, g_height, GL_RGBA, GL_UNSIGNED_BYTE, &px[0]);
	FILE* fp = fopen(path.c_str(), "wb");
	if (!fp) return;
	png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	png_infop info = png_create_info_struct(png);
	if (setjmp(png_jmpbuf(png))) { fclose(fp); return; }
	png_init_io(png, fp);
	png_set_IHDR(png, info, g_width, g_height, 8, PNG_COLOR_TYPE_RGBA, PNG_INTERLACE_NONE,
	             PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
	png_write_info(png, info);
	for (int y = g_height - 1; y >= 0; --y) png_write_row(png, &px[(size_t)y * g_width * 4]);
	png_write_end(png, NULL);
	png_destroy_write_struct(&png, &info);
	fclose(fp);
	LOGI("[autotest] captura guardada: %s\n", path.c_str());
}
#endif

// Gancho: lo llama App::swapBuffers() al final de cada frame
void r36s_swapBuffers() {
#ifdef R36S_AUTOTEST
	if (!g_shotRequest.empty()) {
		saveScreenshotPNG(g_shotRequest);
		g_shotRequest.clear();
	}
#endif
	SDL_GL_SwapWindow(g_window);
}

#ifdef R36S_AUTOTEST
// Guion de pruebas para ejecutar el juego sin mando (solo en la build de pruebas).
// MCPE_AUTOTEST="60:shot=a.png;70:down=dd;75:up=dd;80:axis=ly:-1;200:quit"
struct AtCmd { long frame; std::string cmd; };
static std::vector<AtCmd> g_atCmds;
static PadInput g_fakePad;

static void autotestLoad() {
	memset(&g_fakePad, 0, sizeof(g_fakePad));
	const char* s = getenv("MCPE_AUTOTEST");
	if (!s) return;
	std::string all(s);
	size_t pos = 0;
	while (pos < all.size()) {
		size_t e = all.find(';', pos);
		if (e == std::string::npos) e = all.size();
		std::string item = trimStr(all.substr(pos, e - pos));
		pos = e + 1;
		size_t c = item.find(':');
		if (c == std::string::npos) continue;
		AtCmd a;
		a.frame = atol(item.substr(0, c).c_str());
		a.cmd = item.substr(c + 1);
		g_atCmds.push_back(a);
	}
}

static int atButton(const std::string& n) {
	if (n == "a") return PB_A;   if (n == "b") return PB_B;
	if (n == "x") return PB_X;   if (n == "y") return PB_Y;
	if (n == "back") return PB_BACK; if (n == "start") return PB_START;
	if (n == "l1") return PB_L1; if (n == "r1") return PB_R1;
	if (n == "du") return PB_DU; if (n == "dd") return PB_DD;
	if (n == "dl") return PB_DL; if (n == "dr") return PB_DR;
	return -1;
}

static void autotestStep(long frame, PadInput& out) {
	for (size_t i = 0; i < g_atCmds.size(); ++i) {
		if (g_atCmds[i].frame != frame) continue;
		const std::string& cmd = g_atCmds[i].cmd;
		size_t eq = cmd.find('=');
		const std::string name = (eq == std::string::npos) ? cmd : cmd.substr(0, eq);
		const std::string arg  = (eq == std::string::npos) ? "" : cmd.substr(eq + 1);
		if (name == "down") { int b = atButton(arg); if (b >= 0) g_fakePad.btn[b] = true; }
		else if (name == "up") { int b = atButton(arg); if (b >= 0) g_fakePad.btn[b] = false; }
		else if (name == "axis") {
			size_t c = arg.find(':');
			const std::string an = arg.substr(0, c);
			const float v = (float)atof(arg.substr(c + 1).c_str());
			if (an == "lx") g_fakePad.lx = v; else if (an == "ly") g_fakePad.ly = v;
			else if (an == "rx") g_fakePad.rx = v; else if (an == "ry") g_fakePad.ry = v;
			else if (an == "lt") g_fakePad.lt = v; else if (an == "rt") g_fakePad.rt = v;
		}
		else if (name == "key") tapKey(atoi(arg.c_str()));
		else if (name == "shot") g_shotRequest = arg;
		else if (name == "quit") g_quit = true;
	}
	out = g_fakePad;
}
#endif /* R36S_AUTOTEST */

// ---------------------------------------------------------------------------
// Ventana + contexto GLES2
// ---------------------------------------------------------------------------
static bool createWindowAndContext() {
	Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN;
	if (!g_cfg.windowed) flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;

	const int depths[2] = { 24, 16 };
	for (int i = 0; i < 2 && !g_glctx; ++i) {
		SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, depths[i]);
		SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);

		g_window = SDL_CreateWindow("Minecraft PE", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		                            g_width, g_height, flags);
		if (!g_window) {
			LOGI("SDL_CreateWindow fallo (depth %d): %s\n", depths[i], SDL_GetError());
			continue;
		}
		g_glctx = SDL_GL_CreateContext(g_window);
		if (!g_glctx) {
			LOGI("SDL_GL_CreateContext fallo (depth %d): %s\n", depths[i], SDL_GetError());
			SDL_DestroyWindow(g_window);
			g_window = NULL;
		}
	}
	if (!g_glctx) return false;

	SDL_GL_MakeCurrent(g_window, g_glctx);
	if (SDL_GL_SetSwapInterval(1) != 0) LOGI("vsync no disponible: %s\n", SDL_GetError());

	int w = 0, h = 0;
	SDL_GL_GetDrawableSize(g_window, &w, &h);
	if (w > 0 && h > 0) { g_width = w; g_height = h; }
	LOGI("Ventana lista: %dx%d\n", g_width, g_height);
	return true;
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------
static void changeToGameDir(const char* argv0) {
	const char* home = getenv("MCPE_HOME");
	if (home && *home) {
		if (chdir(home) == 0) return;
	}
	char exe[1024];
	ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
	std::string path;
	if (n > 0) { exe[n] = 0; path = exe; }
	else path = argv0 ? argv0 : "";
	size_t e = path.rfind('/');
	if (e == std::string::npos) return;
	path = path.substr(0, e);
	if (chdir(path.c_str()) != 0) return;
	// si el binario esta en <juego>/bin, los datos estan un nivel arriba
	if (!fileExists("data/images/terrain.png") && fileExists("../data/images/terrain.png")) {
		if (chdir("..") != 0) return;
	}
}

int main(int argc, char** argv) {
	setvbuf(stdout, NULL, _IOLBF, 0);
	memset(g_keyHeld, 0, sizeof(g_keyHeld));

	changeToGameDir(argc > 0 ? argv[0] : NULL);
	loadConfig("controls.cfg");
	if (getenv("MCPE_WINDOWED")) g_cfg.windowed = true;

	if (!fileExists("data/images/terrain.png")) {
		LOGI("ERROR: no encuentro data/images/terrain.png (directorio de trabajo incorrecto)\n");
		return 1;
	}

	SDL_SetHint("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1");
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER) < 0) {
		LOGI("No se pudo inicializar SDL: %s\n", SDL_GetError());
		return -1;
	}
	// mapeos extra opcionales (PortMaster tambien exporta SDL_GAMECONTROLLERCONFIG)
	if (fileExists("gamecontrollerdb.txt")) SDL_GameControllerAddMappingsFromFile("gamecontrollerdb.txt");

	if (!createWindowAndContext()) {
		LOGI("No se pudo crear la ventana/contexto GLES2\n");
		SDL_Quit();
		return -2;
	}
	SDL_ShowCursor(0);

	if (!gles1shim_init((Gles1ShimLoader)SDL_GL_GetProcAddress)) {
		LOGI("No se pudo inicializar la emulacion GLES1 sobre GLES2\n");
		return -3;
	}
	{
		const char* ver = (const char*)glGetString(GL_VERSION);
		const char* ren = (const char*)glGetString(GL_RENDERER);
		LOGI("GL_RENDERER: %s | GL_VERSION: %s\n", ren ? ren : "?", ver ? ver : "?");
	}

	openFirstPad();
	g_curX = g_width / 2.0f;
	g_curY = g_height / 2.0f;

	// Datos guardados (mundos, opciones): MCPE_SAVE o ./savedata
	std::string storagePath;
	const char* sv = getenv("MCPE_SAVE");
	if (sv && *sv) storagePath = sv; else storagePath = "savedata";
	{
		char cwd[1024];
		if (storagePath[0] != '/' && getcwd(cwd, sizeof(cwd))) storagePath = std::string(cwd) + "/" + storagePath;
	}
	if (storagePath[storagePath.size() - 1] != '/') storagePath += "/";
	makeDirs(storagePath + "games/com.mojang/minecraftWorlds");
	makeDirs(storagePath + "games/com.mojang/minecraftpe");

	MAIN_CLASS* game = new MAIN_CLASS();
	game->externalStoragePath = storagePath;
	game->externalCacheStoragePath = storagePath;
	App* app = game;   // init(AppContext&) esta en App (NinecraftApp::init() la oculta)

	AppContext context;
	AppPlatform_linux platform;
	context.doRender = true;
	context.platform = &platform;

	app->init(context);
	app->setSize(g_width, g_height);
	if (g_cfg.viewDistance >= 0 && g_cfg.viewDistance <= 3) game->options.viewDistance = g_cfg.viewDistance;

#ifdef R36S_AUTOTEST
	autotestLoad();
#endif

	Uint32 last = SDL_GetTicks();
	long frame = 0;
	while (!g_quit) {
		const Uint32 now = SDL_GetTicks();
		float dt = (float)(now - last) / 1000.0f;
		last = now;
		if (dt > 0.1f) dt = 0.1f;
		if (dt < 0.0005f) dt = 0.0005f;
#ifdef R36S_AUTOTEST
		dt = 1.0f / 60.0f; // pruebas deterministas: 60 "fps" fijos para los sticks
#endif

		if (handleEvents() != 0) break;

		PadInput pad;
		readPad(pad);
#ifdef R36S_AUTOTEST
		autotestStep(frame, pad);
#endif
		applyPad(pad, dt);

		app->update();
		if (app->wantToQuit()) break;
		++frame;
	}

	// guardar la partida en curso antes de salir
	if (game->level) {
		game->level->saveLevelData();
		game->level->saveGame();
	}
	LOGI("Saliendo...\n");
	fflush(stdout);
	if (g_pad) SDL_GameControllerClose(g_pad);
	SDL_GL_DeleteContext(g_glctx);
	SDL_DestroyWindow(g_window);
	SDL_Quit();
	_exit(0); // evita esperas de hilos de red al cerrar
	return 0;
}

#endif /* MAIN_SDL2_H__ */
