@echo off
REM Compila Minecraft PE para la R36S (aarch64) usando Docker Desktop en Windows.
REM Haz doble clic en este archivo (Docker Desktop debe estar abierto).
cd /d "%~dp0"

where docker >nul 2>nul
if errorlevel 1 (
  echo ERROR: hace falta Docker Desktop: https://www.docker.com/products/docker-desktop/
  pause
  exit /b 1
)

echo ==^> Preparando el entorno de compilacion (la primera vez descarga unos 500 MB)...
docker build -t mcpe-r36s-build .
if errorlevel 1 (
  echo ==^> Reintentando con el espejo archive.debian.org...
  docker build --build-arg DEBIAN_MIRROR=archive.debian.org -t mcpe-r36s-build .
  if errorlevel 1 (
    echo ERROR preparando el entorno. Revisa tu conexion y que Docker este abierto.
    pause
    exit /b 1
  )
)

echo ==^> Compilando...
docker run --rm -v "%~dp0..:/kit" mcpe-r36s-build make -j4 -C /kit/1_COMPILAR_EN_PC OUT=/kit/2_COPIAR_A_LA_CONSOLA/minecraftpe/minecraftpe
if errorlevel 1 (
  echo ERROR compilando. Guarda este texto y mandaselo a Claude.
  pause
  exit /b 1
)

echo.
echo ==^> LISTO. Se creo: 2_COPIAR_A_LA_CONSOLA\minecraftpe\minecraftpe
echo     Ahora copia el CONTENIDO de la carpeta 2_COPIAR_A_LA_CONSOLA a /roms2/ports de tu SD2.
pause
