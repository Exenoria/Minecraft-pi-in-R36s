#!/usr/bin/env bash
# Compila Minecraft PE para la R36S (aarch64) usando Docker.
# Uso (Linux, macOS o WSL):   ./build.sh
set -e
cd "$(dirname "$0")"
KIT_ROOT="$(cd .. && pwd)"
IMAGE=mcpe-r36s-build

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: hace falta Docker (https://www.docker.com/products/docker-desktop/)"
  exit 1
fi

echo "==> Preparando el entorno de compilacion (la primera vez descarga unos 500 MB)..."
if ! docker build -t "$IMAGE" . ; then
  echo "==> Reintentando con el espejo archive.debian.org..."
  docker build --build-arg DEBIAN_MIRROR=archive.debian.org -t "$IMAGE" .
fi

JOBS="$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)"
USER_FLAG=""
if [ "$(uname -s)" = "Linux" ]; then USER_FLAG="--user $(id -u):$(id -g)"; fi

echo "==> Compilando con $JOBS hilos..."
docker run --rm $USER_FLAG -v "$KIT_ROOT:/kit" "$IMAGE" \
  make -j"$JOBS" -C /kit/1_COMPILAR_EN_PC OUT=/kit/2_COPIAR_A_LA_CONSOLA/minecraftpe/minecraftpe

echo
echo "==> LISTO. Se creo: 2_COPIAR_A_LA_CONSOLA/minecraftpe/minecraftpe"
echo "    Ahora copia el CONTENIDO de la carpeta 2_COPIAR_A_LA_CONSOLA a /roms2/ports de tu SD2."
